# Cómo publicar tu sitio en GitHub Pages

Sigue estos pasos — toma unos 5 minutos y tu sitio queda con un link real, accesible desde cualquier navegador.

## 1. Crea una cuenta en GitHub (si no tienes una)
Ve a https://github.com y regístrate gratis.

## 2. Crea un nuevo repositorio
1. Click en el botón **"+"** arriba a la derecha → **"New repository"**
2. Nombre del repositorio: por ejemplo `vacaciones` (puede ser cualquier nombre)
3. Marca la opción **"Public"**
4. NO marques "Add a README" (ya tienes tus archivos)
5. Click en **"Create repository"**

## 3. Sube los archivos
En la página del repositorio recién creado:
1. Click en **"uploading an existing file"** (link azul en el centro)
2. Arrastra **toda la carpeta** `vacacionesusa` que descargaste (o todos los archivos dentro, manteniendo la estructura: `index.html`, `style.css`, y la carpeta `newyork/` con sus 4 archivos)
3. Abajo, en "Commit changes", escribe algo como "Primera versión del sitio"
4. Click en **"Commit changes"**

> **Importante:** la estructura de carpetas debe quedar igual:
> ```
> index.html
> style.css
> newyork/
>   ├── index.html
>   ├── dia1.html
>   ├── dia2.html
>   └── dia3.html
> ```

## 4. Activa GitHub Pages
1. En tu repositorio, ve a **Settings** (pestaña arriba)
2. En el menú izquierdo, click en **Pages**
3. En "Branch", selecciona **main** y la carpeta **/ (root)**
4. Click en **Save**
5. Espera 1-2 minutos y verás un mensaje: *"Your site is live at https://tu-usuario.github.io/vacaciones/"*

## 5. ¡Listo! Tu sitio ya tiene URL real
Tus páginas quedarán así:
- Inicio: `https://tu-usuario.github.io/vacaciones/`
- New York: `https://tu-usuario.github.io/vacaciones/newyork/`
- Día 1: `https://tu-usuario.github.io/vacaciones/newyork/dia1.html`
- Día 2: `https://tu-usuario.github.io/vacaciones/newyork/dia2.html`
- Día 3: `https://tu-usuario.github.io/vacaciones/newyork/dia3.html`

Puedes compartir ese link con quien quieras — funciona en cualquier celular o computadora, y todos los hipervínculos saltan de página en página correctamente.

## Para agregar Washington DC (u otro destino) más adelante
1. Crea una carpeta nueva llamada `washingtondc` (mismo nivel que `newyork`)
2. Dentro, copia la estructura: `index.html`, `dia1.html`, etc.
3. Sube esos archivos nuevos a tu repositorio (botón "Add file" → "Upload files")
4. Agrega la tarjeta del nuevo destino en el `index.html` principal (donde dice "+ Agregar destino")

GitHub Pages se actualiza automáticamente cada vez que subes o cambias archivos — no necesitas hacer nada más.
